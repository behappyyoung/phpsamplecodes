/* Italian initialization for the jQuery UI multiselect plugin. */
/* Written by Vincenzo Farruggia(mastropinguino@networky.net). */

(function ( $ ) {

$.extend($.ech.multiselectfilter.prototype.options, {
	label: "Filtro:",
	placeholder: "Digita una parola chiave"
});

})( jQuery );

